"""WASI transport extensions."""
